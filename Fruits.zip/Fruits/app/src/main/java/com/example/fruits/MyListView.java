package com.example.fruits;

import android.app.Activity;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class MyListView extends ArrayAdapter<String> {

    private final Activity context;
    private final String[] fruits;
    private final String[] Description;
    private final Integer[] imgid;

    public MyListView(Activity context, String[] fruits, String[] Description, Integer[] imgid) {
        super(context, R.layout.mylist, fruits);
        // TODO Auto-generated constructor stub

        this.context=context;
        this.fruits=fruits;
        this.Description=Description;
        this.imgid=imgid;

    }

    public View getView(int position,View view,ViewGroup parent) {
        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.mylist,null,true);

        TextView fruitsView = (TextView) rowView.findViewById(R.id.fruits);
        ImageView imageView = (ImageView) rowView.findViewById(R.id.icon);
        TextView descriptionView = (TextView) rowView.findViewById(R.id.Description);

        fruitsView.setText(fruits[position]);
        imageView.setImageResource(imgid[position]);
        descriptionView.setText(Description[position]);

        return rowView;

    }
}
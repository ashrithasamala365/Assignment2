package com.example.fruits;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ListView list;

    String[] fruits ={
            "Orange","Apple",
            "Banana","Kiwi",
            "Grapes",
    };

    String[] Description ={
            "It is an orange","it is an Apple",
            "It is an banana","It is an Kiwi",
            "It is an grapes ",
    };

    Integer[] imgid={
            R.drawable.img,R.drawable.img_1,
            R.drawable.img_2,R.drawable.img_3,
            R.drawable.img_4,
    };
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MyListView adapter=new MyListView(this, fruits, Description,imgid);
        list=(ListView)findViewById(R.id.listView);
        list.setAdapter(adapter);


        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,int position, long id) {
                // TODO Auto-generated method stub
                if(position == 0) {
                    //code specific to first list item
                    Toast.makeText(getApplicationContext(),"Orange is a sweet fruit \n" +
                            " It is rich in vitamin C.\n"+
                            " Orange is my favorite fruit\n"+
                            " It is a type of citrus fruit which people often eat.\n" +
                            "They are a very good source of vitamin",Toast.LENGTH_SHORT).show();
                }

                else if(position == 1) {
                    //code specific to 2nd list item
                    Toast.makeText(getApplicationContext(),"RawApple is in green colour and ripe apple is red in colour." +
                            " Its taste is good. There are some small seeds inside theApple.\n" +
                            " It is extremely useful for our health.\n" +
                            " The person who eats It every day never will get sick.\n" +
                            " It helps to weight reduction.\n It is very helpful for the pores and skin.",Toast.LENGTH_SHORT).show();
                }

                else if(position == 3) {

                    Toast.makeText(getApplicationContext(),"Kiwi fruit are just the thing for a healthy snack.\n" +
                            "Spoon the glaze over the kiwi fruit.\n" +
                            "The first casualty was the poor Kiwi fruit.",Toast.LENGTH_SHORT).show();
                }
                else if(position == 2) {

                    Toast.makeText(getApplicationContext(),"The banana tree is a plant whose entire plant is popular. \n" +
                            "Its stem, fruit, and leaves all are very useful.\n " +
                            "Banana trees are hardy, easy to grow, and produce delicious fruit.\n" +
                            " They can be grown in a variety of climates, and are useful as an ornamental or a food source.\n",Toast.LENGTH_SHORT).show();
                }
                else if(position == 4) {

                    Toast.makeText(getApplicationContext(),"Grapes are a very juicy and sweet fruit.\n" +
                            "Grapes are in a bunch in which many small grapes are attached.\n" +
                            "Grapes are black and green in color, ripe grapes are light yellow in color and raw grapes are dark green in color.\n" +
                            "Grapes grow on the plant, whose branches are made of vines.",Toast.LENGTH_SHORT).show();
                }


            }
        });
    }
}